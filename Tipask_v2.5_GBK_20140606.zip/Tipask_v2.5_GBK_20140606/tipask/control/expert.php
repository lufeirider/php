<?php

!defined('IN_TIPASK') && exit('Access Denied');

class expertcontrol extends base {

    function expertcontrol(& $get, & $post) {
        $this->base($get, $post);
        $this->load("expert");
    }

    /* ���Ӿٱ� */

    function ondefault() {
        $navtitle = "����ר��";
        $page = max(1, intval($this->get[2]));
        $pagesize = $this->setting['list_default'];
        $startindex = ($page - 1) * $pagesize;
        $rownum = $this->db->fetch_total('user', ' expert=1');
        $expertlist = $_ENV['expert']->get_list(1, $startindex, $pagesize);
        $departstr = page($rownum, $pagesize, $page, "expert/default");
        $questionlist = $_ENV['expert']->get_solves(0, 15);
        include template('expert');
    }

}

?>