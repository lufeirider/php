<?php 
define('WB_AKEY',  '2135218695');
define('WB_SKEY',  'b8cb8a435e835e43e7c66953ebce0abc');
define('WB_CALLBACK_URL',  'http://localhost/tipask-phpask/plugin/sinalogin/callback.php');
